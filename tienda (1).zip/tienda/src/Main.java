import javax.swing.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main
            (String[] args) {

        Scanner scanner = new Scanner(System.in);
        byte opcionPrincipal, opcionSub, opcionsub1;
        String teclado;
        do {
            opcionPrincipal = Byte.parseByte(JOptionPane.showInputDialog(
                    "MENU PRINCIPAL\n"
                            + "1. Tablas\n"
                            + "2. Insertar datos\n"
                            + "3. Actualizar datos\n"
                            + "4. Eliminar datos\n"
                            + "5. Consultas\n"
                            + "6. Salir\n"
                            + "ELIJA SU OPCION"));

            switch (opcionPrincipal) {
                case 1:
                    do {
                        opcionSub = Byte.parseByte(JOptionPane.showInputDialog(
                                "TABLAS\n"
                                        + "1. Clientes\n"
                                        + "2. Compras\n"
                                        + "3. Detalles\n"
                                        + "4. Devoluciones\n"
                                        + "5. Distribuidores\n"
                                        + "6. Empleados\n"
                                        + "7. Pedidos\n"
                                        + "8. Productos\n"
                                        + "9. Pedidos_Productos\n"
                                        + "0. Volver al menu principal\n"
                                        + "ELIJA SU OPCION"));
                        switch (opcionSub) {
                            case 1:
                                if (opcionSub == 1) {
                                    Gestion_Clientes clientes = new Gestion_Clientes();
                                    ArrayList<clientes> resultado = new ArrayList<>();
                                    resultado = clientes.Consultarcliente();
                                    System.out.println(resultado);
                                    for (clientes r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Clientes");
                                        break;
                                    }
                                }
                                break;
                            case 2:
                                if (opcionSub == 2) {
                                    Gestion_Comprar comprar = new Gestion_Comprar();
                                    ArrayList<comprar> resultado = new ArrayList<>();
                                    resultado = comprar.Consultarcompra();
                                    System.out.println(resultado);
                                    for (comprar r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Compras");
                                        break;
                                    }
                                }
                                break;
                            case 3:
                                if (opcionSub == 3) {
                                    Gestion_Detalles detalles = new Gestion_Detalles();
                                    ArrayList<detalles> resultado = new ArrayList<>();
                                    resultado = detalles.Consultardetalle();
                                    System.out.println(resultado);
                                    for (detalles r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Detalles");
                                        break;
                                    }
                                }
                                break;
                            case 4:
                                if (opcionSub == 4) {
                                    Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
                                    ArrayList<devoluciones> resultado = new ArrayList<>();
                                    resultado = devoluciones.Consultardevolucion();
                                    System.out.println(resultado);
                                    for (devoluciones r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Devoluciones");
                                        break;
                                    }
                                }
                                break;
                            case 5:
                                if (opcionSub == 5) {
                                    Gestion_Distribuidores distribuidores = new Gestion_Distribuidores();
                                    ArrayList<distribuidores> resultado = new ArrayList<>();
                                    resultado = distribuidores.Consultardistribuidor();
                                    System.out.println(resultado);
                                    for (distribuidores r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Distribuidores");
                                        break;
                                    }
                                }
                                break;
                            case 6:
                                if (opcionSub == 6) {
                                    Gestion_Empleados empleados = new Gestion_Empleados();
                                    ArrayList<empleados> resultado = new ArrayList<>();
                                    resultado = empleados.Consultarempleados();
                                    System.out.println(resultado);
                                    for (empleados r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Empleados");
                                        break;
                                    }
                                }
                                break;
                            case 7:
                                if (opcionSub == 7) {
                                    Gestion_Pedidos pedidos = new Gestion_Pedidos();
                                    ArrayList<pedidos> resultado = new ArrayList<>();
                                    resultado = pedidos.Consultarpedidos();
                                    System.out.println(resultado);
                                    for (pedidos r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Pedidos");
                                        break;
                                    }
                                }
                                break;
                            case 8:
                                if (opcionSub == 8) {
                                    Gestion_Productos productos = new Gestion_Productos();
                                    ArrayList<productos> resultado = new ArrayList<>();
                                    resultado = productos.Consultarproductos();
                                    System.out.println(resultado);
                                    for (productos r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Productos");
                                        break;
                                    }
                                }
                                break;
                            case 9:
                                if (opcionSub == 9) {
                                    Gestion_Pedidos_Productos pedidos_productos = new Gestion_Pedidos_Productos();
                                    ArrayList<pedidos_productos> resultado = new ArrayList<>();
                                    resultado = pedidos_productos.Consultarpedidos_productos();
                                    System.out.println(resultado);
                                    for (pedidos_productos r : resultado) {
                                        System.out.println(r.toString());
                                        JOptionPane.showMessageDialog(null, "Tabla de Pedidos_Productos");
                                        break;
                                    }
                                }
                                break;
                            case 0:
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Opcion invalida");
                        }
                    } while (opcionSub != 0);
                    break;
                case 2:
                    do {
                        opcionSub = Byte.parseByte(JOptionPane.showInputDialog(
                                "INSERTAR DATOS\n"
                                        + "1. Clientes\n"
                                        + "2. Compras\n"
                                        + "3. Detalles\n"
                                        + "4. Devoluciones\n"
                                        + "5. Distribuidores\n"
                                        + "6. Empleados\n"
                                        + "7. Pedidos\n"
                                        + "8. Productos\n"
                                        + "9. Pedidos_Productos\n"
                                        + "0. Volver al menu principal\n"
                                        + "ELIJA SU OPCION"));
                        switch (opcionSub) {
                            case 1:
                                if (opcionSub == 1) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Clientes clientes = new Gestion_Clientes();
                                    System.out.println("Ingrese los datos para tu tabla Clientes");
                                    System.out.println("Numero de Cedula del Cliente");
                                    String cedula = entrada.next();
                                    System.out.println("Nombre del Cliente");
                                    String nombre = entrada.next();
                                    clientes cl = new clientes(cedula, nombre);
                                    if (clientes.insertarclientes(cl)) {
                                        System.out.println("El cliente se registro exitosamente");
                                    } else System.out.println("El cliente no se registro");
                                }
                                break;
                            case 2:
                                if (opcionSub == 2) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Comprar comprar = new Gestion_Comprar();
                                    System.out.println("Ingrese los datos para tu tabla Compras");
                                    System.out.println("Codigo de Compra");
                                    String codigo = entrada.next();
                                    System.out.println("Numero de Cedula del empleado");
                                    String cedula = entrada.next();
                                    System.out.println("Codigo del Producto de la compra");
                                    int producto = entrada.nextInt();
                                    System.out.println("Cedula del cliente que realiza la compra");
                                    String cliente = entrada.next();
                                    System.out.println("Fecha en que realiza la compra");
                                    String fecha = entrada.next();
                                    System.out.println("Pago de la Compra");
                                    int pago = entrada.nextInt();
                                    System.out.println("Direccion del Establecimiento");
                                    String direccion = entrada.next();
                                    System.out.println("Metodo de pago de la Compra");
                                    String metodo = entrada.next();
                                    comprar cp = new comprar(codigo, cedula, producto, cliente, fecha, pago, direccion, metodo);
                                    if (comprar.insertarcompras(cp)) {
                                        System.out.println("La Compra se registro exitosamente");
                                    } else System.out.println("La Compra no se registro");
                                }
                                break;
                            case 3:
                                if (opcionSub == 3) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Detalles detalles = new Gestion_Detalles();
                                    System.out.println("Ingrese los datos para tu tabla Detalles");
                                    System.out.println("Codigo Identificacion");
                                    int codigo = entrada.nextInt();
                                    System.out.println("Codigo Producto");
                                    int producto = entrada.nextInt();
                                    System.out.println("Codigo compra");
                                    String compra = entrada.next();
                                    System.out.println("Precio");
                                    int precio = entrada.nextInt();
                                    System.out.println("Pago");
                                    int pago = entrada.nextInt();
                                    detalles dt = new detalles(codigo, producto, compra, precio, pago);
                                    if (detalles.insertarDetalles(dt)) {
                                        System.out.println("El Detalle se registro exitosamente");
                                    } else System.out.println("El Detalle no se registro");
                                }
                                break;
                            case 4:
                                if (opcionSub == 4) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
                                    System.out.println("Ingrese los datos para tu tabla Devolucion");
                                    System.out.println("Codigo Devolucion");
                                    int codigo = entrada.nextInt();
                                    System.out.println("Codigo Identificacion");
                                    int identificacion = entrada.nextInt();
                                    System.out.println("Unidades");
                                    int unidades = entrada.nextInt();
                                    devoluciones dv = new devoluciones(codigo, identificacion, unidades);
                                    if (devoluciones.insertardevoluciones(dv)) {
                                        System.out.println("La Devolucion se registro exitosamente");
                                    } else System.out.println("La Devolucion no se registro");
                                }
                                break;
                            case 5:
                                if (opcionSub == 5) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Distribuidores distribuidores = new Gestion_Distribuidores();
                                    System.out.println("Ingrese los datos para tu tabla Distribuidores");
                                    System.out.println("Nit Distribuidor");
                                    String nit = entrada.next();
                                    System.out.println("Nombre del Distribuidor");
                                    String nombre = entrada.next();
                                    distribuidores ds = new distribuidores(nit, nombre);
                                    if (distribuidores.insertarDistribuidores(ds)) {
                                        System.out.println("El Distribuidor se registro exitosamente");
                                    } else System.out.println("El Distribuidor no se registro");
                                }
                                break;
                            case 6:
                                if (opcionSub == 6) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Empleados empleados = new Gestion_Empleados();
                                    System.out.println("Ingrese los datos para tu tabla Empleados");
                                    System.out.println("Cedula Del Empleado");
                                    String cedula = entrada.next();
                                    System.out.println("Nombre del Empleado");
                                    String nombre = entrada.next();
                                    System.out.println("Salario del Empleado");
                                    int salario = entrada.nextInt();
                                    System.out.println("Horario del Empleado");
                                    String horario = entrada.next();
                                    System.out.println("cargo del Empleado");
                                    String cargo = entrada.next();
                                    empleados emp = new empleados(cedula, nombre, horario);
                                    if (empleados.insertarempleados(emp)) {
                                        System.out.println("El Empleado se registro exitosamente");
                                    } else System.out.println("El Empleado no se registro");
                                }
                                break;
                            case 7:
                                if (opcionSub == 7) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Pedidos pedidos = new Gestion_Pedidos();
                                    System.out.println("Ingrese los datos para tu tabla Pedidos");
                                    System.out.println("Codigo del Pedido");
                                    int codigo = entrada.nextInt();
                                    System.out.println("Nit Del Distribuidor");
                                    String nit = entrada.next();
                                    System.out.println("Cantidad Total");
                                    int cantidad = entrada.nextInt();
                                    System.out.println("Costo Neto");
                                    int costo = entrada.nextInt();
                                    pedidos pd = new pedidos(codigo, nit, cantidad, costo);
                                    if (pedidos.insertarpedidos(pd)) {
                                        System.out.println("El Pedido se registro exitosamente");
                                    } else System.out.println("El Pedido no se registro");
                                }

                                break;
                            case 8:
                                if (opcionSub == 8) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Productos productos = new Gestion_Productos();
                                    System.out.println("Ingrese los datos para tu tabla Pedidos");
                                    System.out.println("Codigo del Producto");
                                    int codigo = entrada.nextInt();
                                    System.out.println("Nombre Del Producto");
                                    String nombre = entrada.next();
                                    System.out.println("Codigo Del Pedido");
                                    int codigop = entrada.nextInt();
                                    productos pd = new productos(codigo, nombre, codigop);
                                    if (productos.insertarproductos(pd)) {
                                        System.out.println("El Producto se registro exitosamente");
                                    } else System.out.println("El Producto no se registro");
                                }
                                break;
                            case 9:
                                if (opcionSub == 9) {
                                    Scanner entrada = new Scanner(System.in);
                                    Gestion_Pedidos_Productos pedidos_productos = new Gestion_Pedidos_Productos();
                                    System.out.println("Ingrese los datos para tu tabla Pedidos_Productos");
                                    System.out.println("Codigo del Pedido_Producto");
                                    int codigo = entrada.nextInt();
                                    System.out.println("Codigo del pedido");
                                    int pedido = entrada.nextInt();
                                    System.out.println("Codigo Del Producto");
                                    int codigop = entrada.nextInt();
                                    pedidos_productos pd = new pedidos_productos(codigo, pedido, codigop);
                                    if (pedidos_productos.insertarpedidos_productos(pd)) {
                                        System.out.println("El Pedido_Producto se registro exitosamente");
                                    } else System.out.println("El Pedido_Producto no se registro");
                                }
                                break;
                            case 0:
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Opcion invalida");
                        }
                    } while (opcionSub != 0);
                    break;
                case 3:
                    do {
                        opcionSub = Byte.parseByte(JOptionPane.showInputDialog(
                                "ACTUALIZAR DATOS\n"
                                        + "1. Clientes\n"
                                        + "2. Compras\n"
                                        + "3. Detalles\n"
                                        + "4. Devoluciones\n"
                                        + "5. Distribuidores\n"
                                        + "6. Empleados\n"
                                        + "7. Pedidos\n"
                                        + "8. Productos\n"
                                        + "9. Pedidos_Productos\n"
                                        + "0. Volver al menu principal\n"
                                        + "ELIJA SU OPCION"));
                        switch (opcionSub) {
                            case 1:
                                if (opcionSub == 1) {
                                    Gestion_Clientes clientes = new Gestion_Clientes();
                                    ArrayList<clientes> rt = new ArrayList<>();
                                    System.out.println("Actualize los datos de Clientes");
                                    System.out.println("Cedula Del Cliente:");
                                    String cedula = scanner.next();
                                    System.out.println("Nombre Del Cliente");
                                    String nombre = scanner.next();
                                    clientes cl = new clientes(cedula, nombre);
                                    if (clientes.actualizarclientes(cl)) {
                                        System.out.println("El Cliente no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL CLIENTE SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 2:
                                if (opcionSub == 2) {
                                    Gestion_Comprar comprar = new Gestion_Comprar();
                                    ArrayList<comprar> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Compras");
                                    System.out.println("codigo de Compra:");
                                    String cdg = scanner.next();
                                    System.out.println("cedula del empleado");
                                    String cc = scanner.next();
                                    System.out.println("codigo producto");
                                    int producto = scanner.nextInt();
                                    System.out.println("cedula cliente");
                                    String cliente = scanner.next();
                                    System.out.println("fecha");
                                    String fch = scanner.next();
                                    System.out.println("pago");
                                    int pago = scanner.nextInt();
                                    System.out.println("direccion establecimiento");
                                    String drcc = scanner.next();
                                    System.out.println("Metodo de pago");
                                    String metodo = scanner.next();
                                    comprar cm = new comprar(cdg, cc, producto, cliente, fch, pago, drcc, metodo);
                                    if (comprar.actualizarcompras(cm)) {
                                        System.out.println("La compra no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("LA compra SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 3:
                                if (opcionSub == 3) {
                                    Gestion_Detalles detalles = new Gestion_Detalles();
                                    ArrayList<detalles> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Detalles");
                                    System.out.println("codigo de Identificacion:");
                                    int cdg = scanner.nextInt();
                                    System.out.println("Codigo Producto");
                                    int producto = scanner.nextInt();
                                    System.out.println("codigo compra");
                                    String compra = scanner.next();
                                    System.out.println("Precio");
                                    int precio = scanner.nextInt();
                                    System.out.println("Pago");
                                    int pago = scanner.nextInt();
                                    detalles dt = new detalles(cdg, producto, compra, precio, pago);
                                    if (detalles.actualizarDetalles(dt)) {
                                        System.out.println("El Detalle no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL DETALLE SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 4:
                                if (opcionSub == 4) {
                                    Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
                                    ArrayList<devoluciones> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Devoluciones");
                                    System.out.println("Cod_Devolucion");
                                    int Devolucion = scanner.nextInt();
                                    System.out.println("codigo de Identificacion:");
                                    int cdg = scanner.nextInt();
                                    System.out.println("Unidades");
                                    int und = scanner.nextInt();
                                    devoluciones dv = new devoluciones(Devolucion, cdg, und);
                                    if (devoluciones.actualizardevoluciones(dv)) {
                                        System.out.println("La Devolucion no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("LA DEVOLUCION SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 5:
                                if (opcionSub == 5) {
                                    Gestion_Distribuidores distribuidores = new Gestion_Distribuidores();
                                    ArrayList<distribuidores> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Distribuidores");
                                    System.out.println("Nit_Distribuidor");
                                    String nit = scanner.next();
                                    System.out.println("Nombre_Distribuidor");
                                    String nombre = scanner.next();
                                    distribuidores ds = new distribuidores(nit, nombre);
                                    if (distribuidores.actualizardistribuidores(ds)) {
                                        System.out.println("El distribuidor no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL DISTRIBUIDOR SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 6:
                                if (opcionSub == 6) {
                                    Gestion_Empleados empleados = new Gestion_Empleados();
                                    ArrayList<empleados> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Empleados");
                                    System.out.println("Cedula del Empleado");
                                    String cedula = scanner.next();
                                    System.out.println("Nom_Empleado");
                                    String nombre = scanner.next();
                                    System.out.println("Salario");
                                    int salario = scanner.nextInt();
                                    System.out.println("Horario");
                                    String horario = scanner.next();
                                    System.out.println("Cargo");
                                    String cargo = scanner.next();
                                    empleados emp = new empleados(cedula, nombre, horario);
                                    if (empleados.actualizarEmpleados(emp)) {
                                        System.out.println("El Empleado no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL EMPLEADO SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 7:
                                if (opcionSub == 7) {
                                    Gestion_Pedidos pedidos = new Gestion_Pedidos();
                                    ArrayList<pedidos> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Pedidos");
                                    System.out.println("Cod_Pedido");
                                    int cod = scanner.nextInt();
                                    System.out.println("Nit_Distribuidor");
                                    String nit = scanner.next();
                                    System.out.println("Can_Total");
                                    int can = scanner.nextInt();
                                    System.out.println("Costo Neto");
                                    int cos = scanner.nextInt();
                                    pedidos pds = new pedidos(cod, nit, can, cos);
                                    if (pedidos.actualizarpedidos(pds)) {
                                        System.out.println("El pedido no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL PEDIDO SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 8:
                                if (opcionSub == 8) {
                                    Gestion_Productos productos = new Gestion_Productos();
                                    ArrayList<productos> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Productos");
                                    System.out.println("Cod_Producto");
                                    int cod = scanner.nextInt();
                                    System.out.println("Nom_Producto");
                                    String nom = scanner.next();
                                    System.out.println("Cod_Pedido");
                                    int ped = scanner.nextInt();
                                    productos pcd = new productos(cod, nom, ped);
                                    if (productos.actualizarproductos(pcd)) {
                                        System.out.println("El Producto no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL PRODUCTO SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 9:
                                if (opcionSub == 9) {
                                    Gestion_Pedidos_Productos pedidos_productos = new Gestion_Pedidos_Productos();
                                    ArrayList<pedidos_productos> resultado = new ArrayList<>();
                                    System.out.println("Actualize los datos de Pedidos_Productos");
                                    System.out.println("Codigo");
                                    int cod = scanner.nextInt();
                                    System.out.println("Cod_Pedido");
                                    int pedido = scanner.nextInt();
                                    System.out.println("Cod_Producto");
                                    int prd = scanner.nextInt();
                                    pedidos_productos pdpc = new pedidos_productos(cod, pedido, prd);
                                    if (pedidos_productos.actualizarpedidoproducto(pdpc)) {
                                        System.out.println("El Pedido_Producto no se actualizo exitosamente.");
                                    } else {
                                        System.out.println("EL PEDIDO_PRODUCTO SE ACTUALIZO");
                                    }
                                }
                                break;
                            case 0:
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Opcion invalida");
                        }
                    } while (opcionSub != 0);
                    break;
                case 4:
                    do {
                        opcionSub = Byte.parseByte(JOptionPane.showInputDialog(
                                "ELIMINAR DATOS\n"
                                        + "1. Clientes\n"
                                        + "2. Compras\n"
                                        + "3. Detalles\n"
                                        + "4. Devoluciones\n"
                                        + "5. Distribuidores\n"
                                        + "6. Empleados\n"
                                        + "7. Pedidos\n"
                                        + "8. Productos\n"
                                        + "9. Pedidos_Productos\n"
                                        + "0. Volver al menu principal\n"
                                        + "ELIJA SU OPCION"));
                        switch (opcionSub) {
                            case 1:
                                if (opcionSub == 1) {
                                    Gestion_Clientes clientes = new Gestion_Clientes();
                                    System.out.println("Borrar fila Cliente");
                                    System.out.println("Cedula Cliente a borrar: ");
                                    String cc = scanner.next();
                                    clientes cl = new clientes(cc);
                                    if (clientes.borrarrcliente(String.valueOf(cl))) {
                                        System.out.println("El Cliente  se BORRO exitosamente.");
                                    }

                                }
                                break;
                            case 2:
                                if (opcionSub == 2) {
                                    Gestion_Comprar comprar = new Gestion_Comprar();
                                    System.out.println("Borrar fila Comprar");
                                    System.out.println("Codigo compra a borrar: ");
                                    String cd = scanner.next();
                                    comprar cm = new comprar(cd);
                                    if (comprar.borrarrcompra(String.valueOf(cm))) {
                                        System.out.println("La Compra  se BORRO exitosamente.");
                                    }

                                }
                                break;
                            case 3:
                                if (opcionSub == 3) {
                                    Gestion_Detalles detalles = new Gestion_Detalles();
                                    System.out.println("Borrar fila Detalles");
                                    System.out.println("Codigo De Identificacion a borrar: ");
                                    int det = scanner.nextInt();
                                    detalles cm = new detalles(det);
                                    if (detalles.borrardetalle(cm)) {
                                        System.out.println("El Detalle  se BORRO exitosamente.");
                                    }
                                }
                                break;
                            case 4:
                                if (opcionSub == 4) {
                                    Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
                                    System.out.println("Borrar fila Devoluciones");
                                    System.out.println("Codigo De Devolucion a borrar: ");
                                    int dv = scanner.nextInt();
                                    devoluciones devol = new devoluciones(dv);
                                    if (devoluciones.borrardevolucion(devol)) {
                                        System.out.println("El Detalle  se BORRO exitosamente.");
                                    }
                                }
                                break;
                            case 5:
                                if (opcionSub == 5) {
                                    Gestion_Distribuidores distribuidores = new Gestion_Distribuidores();
                                    System.out.println("Borrar fila Distribuidores");
                                    System.out.println("Nit del Distribuidor a borrar: ");
                                    String nit = scanner.next();
                                    distribuidores dis = new distribuidores(nit);
                                    if (distribuidores.borrarrdistribuidor(String.valueOf(dis))) {
                                        System.out.println("El Distribuidor  se BORRO exitosamente.");
                                    }

                                }
                                break;
                            case 6:
                                if (opcionSub == 6) {
                                    Gestion_Empleados empleados = new Gestion_Empleados();
                                    System.out.println("Borrar fila Empleados");
                                    System.out.println("Cedula Empleado a borrar: ");
                                    String cedula = scanner.next();
                                    empleados emp = new empleados(cedula);
                                    if (empleados.borrarEmpleado(String.valueOf(emp))) {
                                        System.out.println("El Empleado  se BORRO exitosamente.");
                                    }

                                }
                                break;
                            case 7:
                                if (opcionSub == 7) {
                                    Gestion_Pedidos pedidos = new Gestion_Pedidos();
                                    System.out.println("Borrar fila Pedidos");
                                    System.out.println("Codigo De pedidos a borrar: ");
                                    int cd = scanner.nextInt();
                                    pedidos pd = new pedidos(cd);
                                    if (pedidos.borrarPedidos(pd)) {
                                        System.out.println("El PEDIDO  se BORRO exitosamente.");
                                    }
                                }
                                break;
                            case 8:
                                if (opcionSub == 8) {
                                    Gestion_Productos productos = new Gestion_Productos();
                                    System.out.println("Borrar fila Productos");
                                    System.out.println("Codigo De Productos a borrar: ");
                                    int cd = scanner.nextInt();
                                    productos pd = new productos(cd);
                                    if (productos.borrarproductos(pd)) {
                                        System.out.println("El PRODUCTO  se BORRO exitosamente.");
                                    }
                                }
                                break;
                            case 9:
                                if (opcionSub == 9) {
                                    Gestion_Pedidos_Productos pedidos_productos = new Gestion_Pedidos_Productos();
                                    System.out.println("Borrar fila Pedidos_Productos");
                                    System.out.println("Codigo De Pedidos_Productos a borrar: ");
                                    int cd = scanner.nextInt();
                                    pedidos_productos pdpc = new pedidos_productos(cd);
                                    if (pedidos_productos.borrarPedidosProductos(pdpc)) {
                                        System.out.println("El PEDIDO_PRODUCTO  se BORRO exitosamente.");
                                    }
                                }
                                break;
                            case 0:
                                break;
                            default:
                                JOptionPane.showMessageDialog(null, "Opcion invalida");
                        }
                    } while (opcionSub != 0);
                    break;
                case 5:
                    do {
                        opcionSub = Byte.parseByte(JOptionPane.showInputDialog(
                                "CONSULTAS \n"
                                        + "1. SIMPLES\n"
                                        + "2. COMPUESTAS\n"
                                        + "0. Volver al menu principal\n"
                                        + "ELIJA SU OPCION"));
                        switch (opcionSub) {
                            case 1:
                                do {
                                    opcionsub1 = Byte.parseByte(JOptionPane.showInputDialog(
                                            "CONSULTAS SIMPLES \n"
                                                    + "1. Seleccione el nombre ,cedula de los clientes que han pagado mas de 5000\n"
                                                    + "2. Cuantas devoluciones estan registradas en el sistema\n"
                                                    + "3. que empleados se encuentran en el cargo de cajero junto con horarios\n"
                                                    + "4. cuantos gerentes tiene la tienda\n"
                                                    + "5. mostar la cedula,nombre y el salario que gana un empleado en el cargo de cajero\n"
                                                    + "6. mostrar el pago y su metodo en las compras de forma ordenada\n"
                                                    + "7. Selecciona el promedio de los costos de los pedidos\n"
                                                    + "8. la tienda desea saber los pedidos que se hacen que sean menor o igual a 100000 y que el sistema muestre la cantidad\n"
                                                    + "9. se desea saber el codigo del pedido con su respectivo distribuidor para lograr tener un listado de pedidos que sean menor a 100 \n"
                                                    + "10. Muestre el código y el nombre del Distribuidor que tenga un mayor Costo Neto\n"
                                                    + "0. Volver al menu principal\n"
                                                    + "ELIJA SU OPCION"));
                                    switch (opcionsub1) {
                                        case 1:
                                            Gestion_Clientes clientes = new Gestion_Clientes();
                                            System.out.println("Ingrese el pago que realiza el cliente");
                                            teclado = scanner.next();
                                            String mo = teclado;
                                            ArrayList<clientes> resultado7 = new ArrayList<>();
                                            if (clientes.buscarclientesconpagos(mo) == null) {
                                                System.out.println("El tipo de pago no se encuentra");
                                            } else {

                                                resultado7 = clientes.buscarclientesconpagos(teclado);
                                                for (clientes r : resultado7) {
                                                    System.out.println(r.toString());
                                                }
                                                JOptionPane.showMessageDialog(null, "estos son los nombres ,cedulas de los clientes que han pagado mas de 5000");
                                            }
                                            break;
                                        case 2:
                                            Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
                                            ArrayList<devoluciones> resultado = new ArrayList<>();
                                            resultado = devoluciones.buscardevolucionesregistradas();
                                            for (devoluciones r : resultado) {
                                                System.out.println(r.toString());
                                            }
                                            JOptionPane.showMessageDialog(null, " Devoluciones que estan registradas en el sistema");

                                            break;
                                        case 3:
                                            Gestion_Empleados empleados = new Gestion_Empleados();
                                            System.out.println("Ingrese el Cargo del Empleado");
                                            teclado = scanner.next();
                                            String car = teclado;
                                            ArrayList<empleados> resultado2 = new ArrayList<>();
                                            if (empleados.buscarempleados(car) == null) {
                                                System.out.println("El Cargo no se encuentra");
                                            } else {

                                                resultado2 = empleados.buscarempleados(teclado);
                                                for (empleados r : resultado2) {
                                                    System.out.println(r.getNom_Empleado());

                                                    System.out.println(r.getHorario());

                                                    System.out.println(r.getCargo());
                                                }
                                                JOptionPane.showMessageDialog(null, "empleados que se encuentran en el cargo de cajero junto con horarios");
                                            }
                                            break;
                                        case 4:

                                            empleados = new Gestion_Empleados();
                                            ArrayList<empleados> resultado4 = new ArrayList<>();
                                            resultado4 = empleados.buscarcantidaddegerentes();
                                            for (empleados r : resultado4) {
                                                System.out.println(r.toString());
                                            }
                                            JOptionPane.showMessageDialog(null, "La cantidad de gerentes que tiene la tienda");

                                            break;
                                        case 5:

                                            empleados = new Gestion_Empleados();
                                            System.out.println("Ingrese el Cargo del Empleado");
                                            teclado = scanner.next();
                                            car = teclado;
                                            ArrayList<empleados> resultado5 = new ArrayList<>();
                                            if (empleados.buscarcargo(car) == null) {
                                                System.out.println("El Cargo no se encuentra");
                                            } else {

                                                resultado5 = empleados.buscarcargo(teclado);
                                                for (empleados r : resultado5) {
                                                    System.out.println(r.getCc_Empleado());

                                                    System.out.println(r.getNom_Empleado());

                                                    System.out.println(r.getSalario_Empleado());
                                                }
                                                JOptionPane.showMessageDialog(null, " Se mostro la cedula,nombre y  el salario que gana un empleado en el cargo de cajero.\n");
                                            }
                                            break;
                                        case 6:
                                            Gestion_Comprar comprar = new Gestion_Comprar();
                                            ArrayList<comprar> resultado8 = new ArrayList<>();
                                            resultado8 = comprar.consultapagoymetodo();
                                            for (comprar r : resultado8) {
                                                System.out.println(r.getPago());

                                                System.out.println(r.getMetodo_Pago());
                                            }
                                            JOptionPane.showMessageDialog(null, "Se muestra el pago y su metodo en las compras de forma ordenada. ");
                                            break;

                                        case 7:
                                            Gestion_Pedidos gp = new Gestion_Pedidos();
                                            gp.promedioCostosPedidos();

                                            break;

                                        case 8:
                                            Gestion_Pedidos pedidos = new Gestion_Pedidos();
                                            ArrayList<pedidos> resultado11 = new ArrayList<>();
                                            resultado11 = pedidos.buscarcantidad();
                                            for (pedidos r : resultado11) {
                                                System.out.println(r.getCod_Pedido());

                                                System.out.println(r.getNit_Distribuidor());

                                                System.out.println(r.getCan_Total());

                                            }
                                            JOptionPane.showMessageDialog(null, "Se Muestra los pedidos  que sean  menor o igual a 100000 y la cantidad.  ");
                                            break;

                                        case 9:
                                            Gestion_Pedidos pedido = new Gestion_Pedidos();
                                            pedido.listarPedidosMenoresA100();
                                            break;
                                        case 10:
                                            Gestion_Pedidos pedi= new Gestion_Pedidos();
                                            pedi.obtenerDistribuidorConMayorCostoNeto();
                                            break;
                                        case 0:
                                            break;
                                        default:
                                            JOptionPane.showMessageDialog(null, "Opcion invalida");
                                    }


                                    break;
                                } while (opcionSub != 0);
                                break;
                            case 2:
                                do {
                                    opcionsub1 = Byte.parseByte(JOptionPane.showInputDialog(
                                            "CONSULTAS COMPUESTAS \n"
                                                    + "1. Seleccione el nombre, cedula de los clientes que han pagado mas de 5000\n"
                                                    + "2. Cuantas devoluciones estan registradas en el sistema\n"
                                                    + "3. Que empleados se encuentran en el cargo de cajero junto con horarios\n"
                                                    + "4. Cuantos gerentes tiene la tienda\n"
                                                    + "0. Volver al menu principal\n"
                                                    + "ELIJA SU OPCION"));
                                    switch (opcionsub1) {
                                        case 1:
                                            Gestion_Clientes cons1 = new Gestion_Clientes();
                                            cons1.buscarClientes();
                                            break;
                                        case 2:
                                            Gestion_Distribuidores cons2 = new Gestion_Distribuidores();
                                            cons2.buscarDistribuidor();
                                            break;
                                        case 3:
                                            Gestion_Empleados cons3 = new Gestion_Empleados();
                                            cons3.buscarEmpleado();
                                            break;
                                        case 4:
                                            Gestion_Productos cons4 = new Gestion_Productos();
                                            cons4.seleccionarProductosVendidos();
                                            break;
                                        case 0:
                                            break;
                                        default:
                                            JOptionPane.showMessageDialog(null, "Opcion invalida");
                                    }
                                }while (opcionsub1 != 0) ;
                                    break;

                        }
                    } while (opcionPrincipal != 0);
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("opcion invalida");
                    break;

            }
        }while (opcionPrincipal != 0) ;
    }
}

