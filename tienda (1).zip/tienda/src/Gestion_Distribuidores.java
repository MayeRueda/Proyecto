import java.sql.*;
import java.util.ArrayList;

public class Gestion_Distribuidores {
    public ArrayList<distribuidores> Consultardistribuidor;
    Conexion con = new Conexion();
    private ArrayList<distribuidores> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<distribuidores> Consultardistribuidor() {

        try {
            String sql = "select*from distribuidores";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                distribuidores ds = new distribuidores(res.getString(1), res.getString(2));
                datos.add(ds);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public distribuidores buscarNit_Distribuidor(String Nit_Distribuidor) {
        distribuidores ds = null;
        try {
            conec = con.conecta();
            String sql = "select * from distribuidores where Nit_Distribuidor=?";
            ps = conec.prepareStatement(sql);
            ps.setString(1, Nit_Distribuidor);
            res = ps.executeQuery();
            while (res.next()) {
                ds = new distribuidores(res.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return ds;
    }

    public boolean insertarDistribuidores(distribuidores ds) {
        boolean resultado = false;
        Gestion_Distribuidores distribuidores = new Gestion_Distribuidores();
        try {
            if (this.buscarNit_Distribuidor(ds.getNit_Distribuidor()) == null) {
                conec = con.conecta();
                String sql = "insert into distribuidores values (?,?)";
                ps = conec.prepareStatement(sql);
                ps.setString(1, ds.getNit_Distribuidor());
                ps.setString(2, ds.getNombre_Distribuidor());

                resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

            } else {
                System.out.println("El Distribuidor ya esta registrado");
            }

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }
    public  boolean actualizardistribuidores(distribuidores ds){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update distribuidores set Nombre_Distribuidor=? where Nit_Distribuidor=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,ds.getNit_Distribuidor());
            ps.setString(2,ds.getNombre_Distribuidor());
            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarrdistribuidor(String Nit_Distribuidor){
        boolean dis=false;

        try {
            conec=con.conecta();
            String sql="delete from distribuidores where Nit_Distribuidor=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,Nit_Distribuidor);
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return dis;
    }
    public void buscarDistribuidor() {
        try {
            conec = con.conecta();

            String consulta = "SELECT Nombre_distribuidor FROM distribuidores WHERE Nit_Distribuidor IN (SELECT Nit_Distribuidor FROM pedidos WHERE cod_pedido='7986756')";

            // Ejecutar la consulta
            Statement instruccion = conec.createStatement();
            ResultSet resultado = instruccion.executeQuery(consulta);

            // Recorrer los resultados de la consulta
            while (resultado.next()) {
                String nombreDistribuidor = resultado.getString("Nombre_distribuidor");
                System.out.println(nombreDistribuidor);
            }

            // Cerrar el objeto ResultSet, el objeto Statement y la conexión a la base de datos
            resultado.close();
            instruccion.close();
            conec.close();
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
    }

}




