import java.sql.*;
import java.util.ArrayList;

public class Gestion_Devoluciones {
    public ArrayList<devoluciones> Consultardevolucion;
    Conexion con = new Conexion();
    private ArrayList<devoluciones> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<devoluciones> Consultardevolucion() {

        try {
            String sql = "select*from devoluciones";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                devoluciones dv = new devoluciones(res.getInt(1), res.getInt(2), res.getInt(3));
                datos.add(dv);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public devoluciones buscarCod_Devolucion(int Cod_Devolucion) {
        devoluciones dv = null;
        try {
            conec = con.conecta();
            String sql = "select * from devoluciones where Cod_Devolucion=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, Cod_Devolucion);
            res = ps.executeQuery();
            while (res.next()) {
                dv = new devoluciones(res.getInt(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return dv;
    }

    public boolean insertardevoluciones(devoluciones dv) {
        boolean resultado = false;
        Gestion_Devoluciones devoluciones = new Gestion_Devoluciones();
        Gestion_Detalles dt = new Gestion_Detalles();
        try {
            if (this.buscarCod_Devolucion(dv.getCod_Devolucion()) == null) {
                if (dt.buscarCod_Identificacion(dv.getCod_Identificacion()) != null) {
                    conec = con.conecta();
                    String sql = "insert into devoluciones values (?,?,?)";
                    ps = conec.prepareStatement(sql);
                    ps.setInt(1, dv.getCod_Devolucion());
                    ps.setInt(2, dv.getCod_Identificacion());
                    ps.setInt(3, dv.getUnidades());
                    resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos
                } else {
                    System.out.println("El Cod_Identificacion no esta registrado ");
                }
            } else {
                System.out.println("La Devolucion ya esta registrada");
            }

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }

    public boolean actualizardevoluciones(devoluciones dv) {
        boolean rt = false;

        try {
            conec = con.conecta();
            String sql = "update devoluciones set Cod_Identificacion=?,Unidades=? where Cod_Devolucion=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, dv.getCod_Devolucion());
            ps.setInt(2, dv.getCod_Identificacion());
            ps.setInt(3, dv.getUnidades());


            rt = ps.executeUpdate() > 0;


        } catch (SQLException w) {
            System.out.println("error de consulta " + w);
        }
        return rt;
    }

    public boolean borrardevolucion(int Cod_Devolucion){
        boolean dv=false;

        try {
            conec=con.conecta();
            String sql="delete from devoluciones where Cod_Devolucion=?";
            ps=conec.prepareStatement(sql);
            ps.setInt(1,Cod_Devolucion);
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return dv;
    }
    public ArrayList<devoluciones> buscardevolucionesregistradas(){
        datos.clear();
        try {
            conec = con.conecta();
            String sql = "select count(*) as cuenta from devoluciones where Cod_Devolucion\n";
            ps = conec.prepareStatement(sql);
            res = ps.executeQuery();
            while (res.next()) {
                int cantidad=res.getInt("cuenta");
                System.out.println("cuenta: " + cantidad);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
    public boolean borrardevolucion(devoluciones devol) {
        return false;
    }

    public ArrayList<devoluciones> buscardevolucionesregistradas1() {
        ArrayList<devoluciones> datos = new ArrayList<>();

        try {
            conec = con.conecta();
            String sql = "SELECT COUNT(*) AS cuenta FROM devoluciones";
            ps = conec.prepareStatement(sql);
            res = ps.executeQuery();

            while (res.next()) {
                int cantidad = res.getInt("cuenta");
                System.out.println("Cantidad de devoluciones: " + cantidad);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }

        return datos;
    }





}








