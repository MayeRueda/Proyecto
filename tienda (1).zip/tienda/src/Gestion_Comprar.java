import java.sql.*;
import java.util.ArrayList;

public class Gestion_Comprar {
    public ArrayList<comprar> Consultarcompra;
    Conexion con = new Conexion();
    private ArrayList<comprar> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<comprar> Consultarcompra() {

        try {
            String sql = "select*from comprar";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                comprar cm = new comprar(res.getString(1), res.getString(2), res.getInt(3), res.getString(4), res.getString(5), res.getInt(6), res.getString(7), res.getString(8));
                datos.add(cm);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public comprar buscarCod_Compra(String Cod_Compra) {
        comprar cm = null;
        try {
            conec = con.conecta();
            String sql = "select * from comprar where Cod_Compra=?";
            ps = conec.prepareStatement(sql);
            ps.setString(1, Cod_Compra);
            res = ps.executeQuery();
            while (res.next()) {
                cm = new comprar(res.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return cm;
    }

    public boolean insertarcompras(comprar cm) {
        boolean resultado = false;
        Gestion_Comprar cp = new Gestion_Comprar();
        Gestion_Empleados emp = new Gestion_Empleados();
        Gestion_Productos pd = new Gestion_Productos();
        Gestion_Clientes cl = new Gestion_Clientes();
        try {
            if (this.buscarCod_Compra(cm.getCod_Compra()) == null) {
                if (emp.buscarcc_empleado(cm.getCc_Empleado()) != null) {
                    if (pd.buscarCod_Producto(cm.getCod_Producto()) != null) {
                        if (cl.buscarCC_Cliente(cm.getCC_Cliente()) != null) {


                            conec = con.conecta();
                            String sql = "insert into comprar values (?,?,?,?,?,?,?,?)";
                            ps = conec.prepareStatement(sql);
                            ps.setString(1, cm.getCod_Compra());
                            ps.setString(2, cm.getCod_Compra());
                            ps.setInt(3, cm.getCod_Producto());
                            ps.setString(4, cm.getCC_Cliente());
                            ps.setString(5, cm.getFecha());
                            ps.setInt(6, cm.getPago());
                            ps.setString(7, cm.getD_Establecimiento());
                            ps.setString(8, cm.getMetodo_Pago());
                            resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos
                        } else {
                            System.out.println("El CC_Cliente no esta registrado ");
                        }
                    } else {
                        System.out.println("El Cod_Producto no esta registrado ");
                    }
                } else {
                    System.out.println("El Cc_Empleado no esta registrado ");
                }
            } else {
                System.out.println("El Cod_Compra ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }

    public  boolean actualizarcompras(comprar cm){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update comprar set Cc_Empleado=?,Cod_Producto=?,CC_Cliente=?,Fecha=?,Pago=?,D_Establecimiento=?,Metodo_Pago=? where Cod_Compra=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,cm.getCod_Compra());
            ps.setString(2,cm.getCc_Empleado());
            ps.setInt(3,cm.getCod_Producto());
            ps.setString(4,cm.getCC_Cliente());
            ps.setString(5,cm.getFecha());
            ps.setInt(6,cm.getPago());
            ps.setString(7,cm.getD_Establecimiento());
            ps.setString(8,cm.getMetodo_Pago());



            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }

    public boolean borrarrcompra(String Cod_Compra){
        boolean comp=false;

        try {
            conec=con.conecta();
            String sql="delete from comprar where Cod_Compra=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,Cod_Compra);
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return comp;
    }
    public ArrayList<comprar> consultapagoymetodo() {
        datos.clear();
        try {
            conec = con.conecta();
            String sql = " select Pago,Metodo_Pago  from comprar order by Pago,Metodo_Pago\n";
            ps = conec.prepareStatement(sql);
            res = ps.executeQuery();
            while (res.next()) {
                comprar cm = new comprar(res.getInt(1),res.getString(2));
                datos.add(cm);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
}





