public class productos {
    public int Cod_Producto;
    public String Nom_Producto;
    public int Cod_Pedido;

    public productos(int cod_Producto, String nom_Producto, int cod_Pedido) {
        Cod_Producto = cod_Producto;
        Nom_Producto = nom_Producto;
        Cod_Pedido = cod_Pedido;
    }

    public productos(int cod_Producto) {
        Cod_Producto = cod_Producto;
    }

    public int getCod_Producto() {
        return Cod_Producto;
    }

    public void setCod_Producto(int cod_Producto) {
        Cod_Producto = cod_Producto;
    }

    public String getNom_Producto() {
        return Nom_Producto;
    }

    public void setNom_Producto(String nom_Producto) {
        Nom_Producto = nom_Producto;
    }

    public int getCod_Pedido() {
        return Cod_Pedido;
    }

    public void setCod_Pedido(int cod_Pedido) {
        Cod_Pedido = cod_Pedido;
    }

    public productos() {
    }

    @Override
    public String toString() {
        return "productos{" +
                "\nCod_Producto: " + Cod_Producto +
                "\nNom_Producto: " + Nom_Producto + '\'' +
                "\nCod_Pedido:  " + Cod_Pedido +
                "\n\n";
    }
}
