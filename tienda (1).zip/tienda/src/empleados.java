public class empleados {
    public String cc_Empleado;
    public String Nom_Empleado;
    public  int Salario_Empleado;
    public String Horario;
    public String Cargo;

    public empleados(String cc_Empleado, String nom_Empleado, int salario_Empleado, String horario, String cargo) {
        this.cc_Empleado = cc_Empleado;
        Nom_Empleado = nom_Empleado;
        Salario_Empleado = salario_Empleado;
        Horario = horario;
        Cargo = cargo;
    }

    public empleados(String cc_Empleado, String nom_Empleado, String horario) {
        this.cc_Empleado = cc_Empleado;
        Nom_Empleado = nom_Empleado;
        Horario = horario;
    }



    public empleados(String cc_Empleado) {
        this.cc_Empleado = cc_Empleado;
    }

    public String getCc_Empleado() {
        return cc_Empleado;
    }

    public void setCc_Empleado(String cc_Empleado) {
        this.cc_Empleado = cc_Empleado;
    }

    public String getNom_Empleado() {
        return Nom_Empleado;
    }

    public void setNom_Empleado(String nom_Empleado) {
        Nom_Empleado = nom_Empleado;
    }

    public int getSalario_Empleado() {
        return Salario_Empleado;
    }

    public void setSalario_Empleado(int Salario_Empleado) {
        Salario_Empleado = Salario_Empleado;
    }

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String horario) {
        Horario = horario;
    }

    public String getCargo() {
        return Cargo;
    }

    public void setCargo(String Cargo) {Cargo = Cargo;}

    public empleados() {
    }

    @Override
    public String toString() {
        return "empleados{" +
                "\ncc_Empleado: " + cc_Empleado + '\'' +
                "\nNom_Empleado: " + Nom_Empleado + '\'' +
                "\nSalario_Empleado: " + Salario_Empleado +
                "\nHorario: " + Horario + '\'' +
                "\nCargo: " + Cargo + '\'' +
                "\n\n";
    }
}
