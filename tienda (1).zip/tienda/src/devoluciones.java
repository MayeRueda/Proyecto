public class devoluciones {
    public int Cod_Devolucion;
    public int Cod_Identificacion;
    public int Unidades;

    public devoluciones(int cod_Devolucion, int cod_Identificacion, int unidades) {
        Cod_Devolucion = cod_Devolucion;
        Cod_Identificacion = cod_Identificacion;
        Unidades = unidades;
    }

    public devoluciones(int cod_Devolucion) {
        Cod_Devolucion = cod_Devolucion;
    }

    public int getCod_Devolucion() {
        return Cod_Devolucion;
    }

    public void setCod_Devolucion(int cod_Devolucion) {
        Cod_Devolucion = cod_Devolucion;
    }

    public int getCod_Identificacion() {
        return Cod_Identificacion;
    }

    public void setCod_Identificacion(int cod_Identificacion) {
        Cod_Identificacion = cod_Identificacion;
    }

    public int getUnidades() {
        return Unidades;
    }

    public void setUnidades(int unidades) {
        Unidades = unidades;
    }

    public devoluciones() {
    }

    @Override
    public String toString() {
        return "devoluciones{" +
                "\nCod_Devolucion: " + Cod_Devolucion +
                "\nCod_Identificacion: " + Cod_Identificacion + '\'' +
                "\nUnidades: " + Unidades +
                "\n\n";
    }
}
