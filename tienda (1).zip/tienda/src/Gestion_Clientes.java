import java.sql.*;
import java.util.ArrayList;

public class Gestion_Clientes {
    public ArrayList<clientes> Consultarcliente;
    Conexion con = new Conexion();
    private ArrayList<clientes> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<clientes> Consultarcliente() {

        try {
            String sql = "select*from clientes";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                clientes cl = new clientes(res.getString(1));
                datos.add(cl);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public clientes buscarCC_Cliente(String CC_Cliente) {
        clientes cl = null;
        try {
            conec = con.conecta();
            String sql = "select * from clientes where CC_Cliente=?";
            ps = conec.prepareStatement(sql);
            ps.setString(1, CC_Cliente);
            res = ps.executeQuery();
            while (res.next()) {
                cl = new clientes(res.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return cl;
    }

    public boolean insertarclientes(clientes cl) {
        boolean resultado = false;
        Gestion_Clientes clientes = new Gestion_Clientes();
        try {
            if (this.buscarCC_Cliente(cl.getCC_Cliente()) == null) {
                conec = con.conecta();
                String sql = "insert into clientes values (?,?)";
                ps = conec.prepareStatement(sql);
                ps.setString(1, cl.getCC_Cliente());
                ps.setString(2, cl.getNom_Cliente());
                resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

            } else {
                System.out.println("El cliente ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }


    public  boolean actualizarclientes(clientes cl){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update clientes set Nom_Cliente=? where CC_Cliente=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,cl.getCC_Cliente());
            ps.setString(2,cl.getNom_Cliente());

            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarrcliente(String CC_Cliente){
        boolean cliente=false;

        try {
            conec=con.conecta();
            String sql="delete from clientes where CC_Cliente=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,CC_Cliente);
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return cliente;
    }
    public void buscarClientes() {
        try {
            conec=con.conecta();

            String consulta = "SELECT Nom_cliente FROM clientes WHERE cc_cliente IN (SELECT cc_cliente FROM comprar WHERE pago < 7000)";

            // Ejecutar la consulta
            Statement instruccion = conec.createStatement();
            ResultSet resultado = instruccion.executeQuery(consulta);

            // Recorrer los resultados de la consulta
            while (resultado.next()) {
                String nombreCliente = resultado.getString("Nom_cliente");
                System.out.println(nombreCliente);
            }

            // Cerrar el objeto ResultSet, el objeto Statement y la conexión a la base de datos
            resultado.close();
            instruccion.close();
            conec.close();
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
    }
    public ArrayList<clientes> buscarclientesconpagos(String clientes) {
        datos.clear();
        try {
            conec = con.conecta();
            String sql = "select CC_Cliente,Nom_Cliente from clientes,Detalles where Pago>=? group by cc_cliente\n";
            ps = conec.prepareStatement(sql);
            ps.setString(1, clientes);
            res = ps.executeQuery();
            while (res.next()) {
                clientes cl = new clientes(res.getString(1),res.getString(2));
                datos.add(cl);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
}






