public class comprar {
    public String Cod_Compra;
    public String cc_Empleado;
    public int Cod_Producto;
    public String CC_Cliente;
    public String Fecha;
    public int Pago;
    public String D_Establecimiento;
    public String Metodo_Pago;

    public comprar(String cod_Compra, String cc_Empleado, int cod_Producto, String CC_Cliente, String fecha, int pago, String d_Establecimiento, String metodo_Pago) {
        Cod_Compra = cod_Compra;
        this.cc_Empleado = cc_Empleado;
        Cod_Producto = cod_Producto;
        this.CC_Cliente = CC_Cliente;
        Fecha = fecha;
        Pago = pago;
        D_Establecimiento = d_Establecimiento;
        Metodo_Pago = metodo_Pago;
    }
    public comprar(int pago, String metodo_Pago) {
        Pago = pago;
        Metodo_Pago = metodo_Pago;
    }

    public comprar(String cod_Compra) {
        Cod_Compra = cod_Compra;
    }

    public String getCod_Compra() {
        return Cod_Compra;
    }

    public void setCod_Compra(String cod_Compra) {
        Cod_Compra = cod_Compra;
    }

    public String getCc_Empleado() {
        return cc_Empleado;
    }

    public void setCc_Empleado(String cc_Empleado) {
        this.cc_Empleado = cc_Empleado;
    }

    public int getCod_Producto() {
        return Cod_Producto;
    }

    public void setCod_Producto(int cod_Producto) {
        Cod_Producto = cod_Producto;
    }

    public String getCC_Cliente() {
        return CC_Cliente;
    }

    public void setCC_Cliente(String CC_Cliente) {
        this.CC_Cliente = CC_Cliente;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public int getPago() {
        return Pago;
    }

    public void setPago(int pago) {
        Pago = pago;
    }

    public String getD_Establecimiento() {
        return D_Establecimiento;
    }

    public void setD_Establecimiento(String d_Establecimiento) {
        D_Establecimiento = d_Establecimiento;
    }

    public String getMetodo_Pago() {
        return Metodo_Pago;
    }

    public void setMetodo_Pago(String metodo_Pago) {
        Metodo_Pago = metodo_Pago;
    }

    public comprar() {
    }

    @Override
    public String toString() {
        return "comprar{" +
                "\nCod_Compra: " + Cod_Compra + '\'' +
                "\ncc_Empleado: " + cc_Empleado + '\'' +
                "\nCod_Producto: " + Cod_Producto + '\'' +
                "\nCC_Cliente: " + CC_Cliente + '\'' +
                "\nFecha: " + Fecha +
                "\nPago: " + Pago +
                "\nD_Establecimiento: " + D_Establecimiento +
                "\nMetodo_Pago: " + Metodo_Pago + '\'' +
                "\n\n";
    }
}
