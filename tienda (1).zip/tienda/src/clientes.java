public class clientes {
    public String CC_Cliente;
    public String Nom_Cliente;

    public clientes(String CC_Cliente) {
        this.CC_Cliente = CC_Cliente;
        String nom_Cliente = null;
        Nom_Cliente = nom_Cliente;
    }

    public clientes(String CC_Cliente, String nom_Cliente) {
        this.CC_Cliente = CC_Cliente;
        Nom_Cliente = nom_Cliente;
    }

    public String getCC_Cliente() {
        return CC_Cliente;
    }

    public void setCC_Cliente(String CC_Cliente) {
        this.CC_Cliente = CC_Cliente;
    }

    public String getNom_Cliente() {
        return Nom_Cliente;
    }

    public void setNom_Cliente(String nom_Cliente) {
        Nom_Cliente = nom_Cliente;
    }

    public clientes() {
    }

    @Override
    public String toString() {
        return "clientes{" +
                "\nCC_Cliente: " + CC_Cliente + '\'' +
                "\nNom_Cliente: " + Nom_Cliente + '\'' +
                "\n\n";
    }

}
