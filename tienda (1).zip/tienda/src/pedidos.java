public class pedidos {
    public int Cod_Pedido;
    public String Nit_Distribuidor;
    public int Can_Total;
    public int Costo_Neto;

    public pedidos(int cod_Pedido, String nit_Distribuidor, int can_Total, int costo_Neto) {
        Cod_Pedido = cod_Pedido;
        Nit_Distribuidor = nit_Distribuidor;
        Can_Total = can_Total;
        Costo_Neto = costo_Neto;
    }
    public pedidos(int cod_Pedido, String nit_Distribuidor, int can_Total) {
        Cod_Pedido = cod_Pedido;
        Nit_Distribuidor = nit_Distribuidor;
        Can_Total = can_Total;
    }
    public pedidos(int cod_Pedido) {
        Cod_Pedido = cod_Pedido;
    }

    public int getCod_Pedido() {
        return Cod_Pedido;
    }

    public void setCod_Pedido(int cod_Pedido) {
        Cod_Pedido = cod_Pedido;
    }

    public String getNit_Distribuidor() {
        return Nit_Distribuidor;
    }

    public void setNit_Distribuidor(String nit_Distribuidor) {
        Nit_Distribuidor = nit_Distribuidor;
    }

    public int getCan_Total() {
        return Can_Total;
    }

    public void setCan_Total(int can_Total) {
        Can_Total = can_Total;
    }

    public int getCosto_Neto() {
        return Costo_Neto;
    }

    public void setCosto_Neto(int costo_Neto) {
        Costo_Neto = costo_Neto;
    }

    public pedidos() {
    }

    @Override
    public String toString() {
        return "pedidos{" +
                "\nCod_Pedido: " + Cod_Pedido +
                "\nNit_Distribuidor: " + Nit_Distribuidor + '\'' +
                "\nCan_Total: " + Can_Total +
                "\nCosto_Neto: " + Costo_Neto +
                "\n\n";
    }
}
