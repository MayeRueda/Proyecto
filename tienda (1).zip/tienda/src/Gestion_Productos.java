import java.sql.*;
import java.util.ArrayList;

public class Gestion_Productos {
    public ArrayList<devoluciones> Consultarproductos;
    Conexion con = new Conexion();
    private ArrayList<productos> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<productos> Consultarproductos() {

        try {
            String sql = "select*from productos";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                productos pc = new productos(res.getInt(1),res.getString(2),res.getInt(3));
                datos.add(pc);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }
    public productos buscarCod_Producto(int Cod_Producto) {
        productos pd = null;
        try {
            conec = con.conecta();
            String sql = "select * from productos where Cod_Producto=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, Cod_Producto);
            res = ps.executeQuery();
            while (res.next()) {
                pd = new productos(res.getInt(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return pd;
    }

    public boolean insertarproductos(productos pd) {
        boolean resultado = false;
        Gestion_Productos productos = new Gestion_Productos();
        Gestion_Pedidos dl = new Gestion_Pedidos();
        try {
            if (this.buscarCod_Producto(pd.getCod_Producto()) == null) {
                if (dl.buscarCod_Pedido(pd.getCod_Pedido()) != null) {
                    conec = con.conecta();
                    String sql = "insert into productos values (?,?,?)";
                    ps = conec.prepareStatement(sql);
                    ps.setInt(1, pd.getCod_Producto());
                    ps.setString(2, pd.getNom_Producto());
                    ps.setInt(3, pd.getCod_Pedido());
                    resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

                } else {
                    System.out.println("El Cod_Pedido no esta registrado ");
                }
            } else {
                System.out.println("El Producto ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }
    public  boolean actualizarproductos(productos pcd){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update productos set Nom_Producto=?,Cod_Pedido=? where Cod_Producto=?";
            ps=conec.prepareStatement(sql);
            ps.setInt(1,pcd.getCod_Producto());
            ps.setString(2,pcd.getNom_Producto());
            ps.setInt(3,pcd.getCod_Pedido());

            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarproductos(productos pdc) {
        boolean resultado = false;
        try {
            conec = con.conecta();
            String sql = "DELETE FROM productos WHERE Cod_Producto = ?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, pdc.getCod_Producto());
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return resultado;
    }
    public void seleccionarProductosVendidos() {
        try {
            conec = con.conecta();

            String consulta = "select Cod_Producto,Nom_Producto from productos where Cod_Producto in (select Cod_producto from comprar where comprar.cod_producto=productos.cod_producto)";

            Statement instruccion = conec.createStatement();
            ResultSet resultado = instruccion.executeQuery(consulta);

            while (resultado.next()) {
                String codigoProducto = resultado.getString("Cod_Producto");
                String nombreProducto = resultado.getString("Nom_Producto");
                System.out.println(codigoProducto + " " + nombreProducto);
            }
            resultado.close();
            instruccion.close();
            conec.close();
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
    }
}
