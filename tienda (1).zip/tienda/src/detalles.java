public class detalles {
    public int Cod_Identificacion;
    public int Cod_Producto;
    public String Cod_Compra;
    public int Precio;
    public  int Pago;

    public detalles(int cod_Identificacion, int cod_Producto, String cod_Compra, int precio, int pago) {
        Cod_Identificacion = cod_Identificacion;
        Cod_Producto = cod_Producto;
        Cod_Compra = cod_Compra;
        Precio = precio;
        Pago = pago;
    }

    public detalles(int cod_Identificacion) {
        Cod_Identificacion = cod_Identificacion;
    }

    public int getCod_Identificacion() {
        return Cod_Identificacion;
    }

    public void setCod_Identificacion(int cod_Identificacion) {
        Cod_Identificacion = cod_Identificacion;
    }

    public int getCod_Producto() {
        return Cod_Producto;
    }

    public void setCod_Producto(int cod_Producto) {
        Cod_Producto = cod_Producto;
    }

    public String getCod_Compra() {
        return Cod_Compra;
    }

    public void setCod_Compra(String cod_Compra) {
        Cod_Compra = cod_Compra;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int precio) {
        Precio = precio;
    }

    public int getPago() {
        return Pago;
    }

    public void setPago(int pago) {
        Pago = pago;
    }

    public detalles() {
    }

    @Override
    public String toString() {
        return "detalles{" +
                "\nCod_Identificacion: " + Cod_Identificacion +
                "\nCod_Producto: " + Cod_Producto + '\'' +
                "\nCod_Compra: " + Cod_Compra + '\'' +
                "\nPrecio: " + Precio +
                "\nPago: " + Pago +
                "\n\n";
    }
}
