import java.sql.*;
import java.util.ArrayList;

public class Gestion_Detalles {
    public ArrayList<detalles> Consultardetalle;
    Conexion con = new Conexion();
    private ArrayList<detalles> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<detalles> Consultardetalle() {

        try {
            String sql = "select*from detalles";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                detalles dt = new detalles(res.getInt(1), res.getInt(2), res.getString(3), res.getInt(4), res.getInt(5));
                datos.add(dt);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public detalles buscarCod_Identificacion(int Cod_Identificacion) {
        detalles dt = null;
        try {
            conec = con.conecta();
            String sql = "select * from detalles where Cod_Identificacion=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, Cod_Identificacion);
            res = ps.executeQuery();
            while (res.next()) {
                dt = new detalles(res.getInt(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return dt;
    }

    public boolean insertarDetalles(detalles dt) {
        boolean resultado = false;
        Gestion_Detalles detalles = new Gestion_Detalles();
        Gestion_Comprar cm = new Gestion_Comprar();
        Gestion_Productos pd = new Gestion_Productos();

        try {
            if (this.buscarCod_Identificacion(dt.getCod_Identificacion()) == null) {
                if (cm.buscarCod_Compra(dt.getCod_Compra()) != null) {
                    if (pd.buscarCod_Producto(dt.getCod_Producto()) != null) {
                        conec = con.conecta();
                        String sql = "insert into detalles values (?,?,?,?,?)";
                        ps = conec.prepareStatement(sql);
                        ps.setInt(1, dt.getCod_Identificacion());
                        ps.setInt(2, dt.getCod_Producto());
                        ps.setString(3, dt.getCod_Compra());
                        ps.setInt(4, dt.getPrecio());
                        ps.setInt(5, dt.getPago());
                        resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

                    } else {
                        System.out.println("El Cod_Producto no esta registrado ");
                    }
                } else {
                    System.out.println("El Cod_Compra no esta registrado ");
                }
            } else {
                System.out.println("El Detalle ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }

    public boolean actualizarDetalles(detalles dt) {
        boolean rt = false;

        try {
            conec = con.conecta();
            String sql = "update detalles set Cod_Producto=?,Cod_Compra=?,Precio=?,Pago=? where Cod_Identificacion=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, dt.getCod_Identificacion());
            ps.setInt(2, dt.getCod_Producto());
            ps.setString(3, dt.getCod_Compra());
            ps.setInt(4, dt.getPrecio());
            ps.setInt(5, dt.getPago());
            rt = ps.executeUpdate() > 0;


        } catch (SQLException w) {
            System.out.println("error de consulta " + w);
        }
        return rt;
    }

    public boolean borrardetalle(detalles det) {
        boolean resultado = false;
        try {
            conec = con.conecta();
            String sql = "DELETE FROM detalles WHERE Cod_Identificacion = ?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, det.getCod_Identificacion());
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return resultado;
    }
}





