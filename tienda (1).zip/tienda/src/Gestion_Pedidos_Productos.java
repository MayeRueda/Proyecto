import java.sql.*;
import java.util.ArrayList;

public class Gestion_Pedidos_Productos {
    public ArrayList<pedidos_productos> Consultarpedidos_productos;
    Conexion con = new Conexion();
    private ArrayList<pedidos_productos> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<pedidos_productos> Consultarpedidos_productos() {

        try {
            String sql = "select*from pedidos_productos";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                pedidos_productos ppd = new pedidos_productos(res.getInt(1),res.getInt(2),res.getInt(3));
                datos.add(ppd);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }
    public pedidos_productos buscarCod(int Cod) {
        pedidos_productos pdyd = null;
        try {
            conec = con.conecta();
            String sql = "select * from pedidos_productos where Cod=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, Cod);
            res = ps.executeQuery();
            while (res.next()) {
                pdyd = new pedidos_productos(res.getInt(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return pdyd;
    }

    public boolean insertarpedidos_productos(pedidos_productos pdyd) {
        boolean resultado = false;
        Gestion_Pedidos_Productos pedidos_productos = new Gestion_Pedidos_Productos();
        Gestion_Pedidos pd = new Gestion_Pedidos();
        Gestion_Productos prd = new Gestion_Productos();
        try {
            if (this.buscarCod(pdyd.getCod()) == null) {
                if (pd.buscarCod_Pedido(pdyd.getCod_Pedido()) != null) {
                    if (prd.buscarCod_Producto(pdyd.getCod_Producto()) != null) {
                        conec = con.conecta();
                        String sql = "insert into pedidos_productos values (?,?,?)";
                        ps = conec.prepareStatement(sql);
                        ps.setInt(1, pdyd.getCod());
                        ps.setInt(2, pdyd.getCod_Pedido());
                        ps.setInt(3, pdyd.getCod_Producto());
                        resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos
                } else {
                    System.out.println("El Cod_Producto no esta registrado ");
                }
                } else {
                    System.out.println("El Cod_Pedido no esta registrado ");
                }
            } else {
                System.out.println("El Pedido_Producto ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }
    public  boolean actualizarpedidoproducto(pedidos_productos pdpcd){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update pedidos_productos set Cod_Pedido=?,Cod_Producto=? where Cod=?";
            ps=conec.prepareStatement(sql);
            ps.setInt(1,pdpcd.getCod());
            ps.setInt(2,pdpcd.getCod_Pedido());
            ps.setInt(3,pdpcd.getCod_Producto());
            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarPedidosProductos(pedidos_productos pdpc) {
        boolean resultado = false;
        try {
            conec = con.conecta();
            String sql = "DELETE FROM pedidos_productos WHERE Cod = ?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, pdpc.getCod());
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return resultado;
    }
}