import java.sql.*;
import java.util.ArrayList;

public class Gestion_Empleados {
    public ArrayList<empleados> Consultarempleados;
    Conexion con = new Conexion();
    private ArrayList<empleados> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<empleados> Consultarempleados() {

        try {
            String sql = "select*from empleados";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                empleados em = new empleados(res.getString(1),res.getString(2), res.getString(4));
                datos.add(em);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }
    public empleados buscarcc_empleado(String cc_Empleado) {
        empleados emp = null;
        try {
            conec = con.conecta();
            String sql = "select * from empleados where cc_Empleado=?";
            ps = conec.prepareStatement(sql);
            ps.setString(1, cc_Empleado);
            res = ps.executeQuery();
            while (res.next()) {
                emp = new empleados(res.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return emp;
    }

    public boolean insertarempleados(empleados emp) {
        boolean resultado = false;
        Gestion_Empleados empleados = new Gestion_Empleados();
        try {
            if (this.buscarcc_empleado(emp.getCc_Empleado()) == null) {
                conec = con.conecta();
                String sql = "insert into empleados values (?,?,?,?,?)";
                ps = conec.prepareStatement(sql);
                ps.setString(1, emp.getCc_Empleado());
                ps.setString(2, emp.getNom_Empleado());
                ps.setInt(3, emp.getSalario_Empleado());
                ps.setString(4, emp.getHorario());
                ps.setString(5, emp.getCargo());
                resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

            } else {
                System.out.println("El Empleado ya esta registrado");
            }

        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }
    public  boolean actualizarEmpleados(empleados emp){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update empleado set getNom_Empleado=?,Salario_Empleado=?,Horario=?,Cargo=? where cc_empleado=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,emp.getCc_Empleado());
            ps.setString(2,emp.getNom_Empleado());
            ps.setInt(3,emp.getSalario_Empleado());
            ps.setString(4,emp.getHorario());
            ps.setString(5,emp.getCargo());
            rt=ps.executeUpdate()>0;
        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarEmpleado(String cc_Empleado){
        boolean emp=false;

        try {
            conec=con.conecta();
            String sql="delete from empleados where cc_Empleado=?";
            ps=conec.prepareStatement(sql);
            ps.setString(1,cc_Empleado);
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return emp;
    }
    public void buscarEmpleado() {
        try {
            conec = con.conecta();

            String consulta = "SELECT nom_empleado FROM Empleados WHERE cc_empleado IN (SELECT cc_empleado FROM comprar WHERE Cod_Producto=15697773)";

            Statement instruccion = conec.createStatement();
            ResultSet resultado = instruccion.executeQuery(consulta);

            while (resultado.next()) {
                String nombreEmpleado = resultado.getString("nom_empleado");
                System.out.println(nombreEmpleado);
            }
            resultado.close();
            instruccion.close();
            conec.close();
        } catch (SQLException e) {
            System.out.println("Error al ejecutar la consulta: " + e.getMessage());
        }
    }
    public ArrayList<empleados> buscarempleados(String clientes) {
        datos.clear();
        try {
            conec = con.conecta();
            String sql = " select Nom_Empleado,horario,cargo from empleados where cargo=?";
            ps = conec.prepareStatement(sql);
            ps.setString(1, clientes);
            res = ps.executeQuery();
            while (res.next()) {
                empleados emp = new empleados(res.getString(1),res.getString(2),res.getString(3));
                datos.add(emp);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
    public ArrayList<empleados> buscarcantidaddegerentes(){
        datos.clear();
        try {
            conec = con.conecta();
            String sql = "select count(*) as cantidad from empleados where cargo=\"gerente\"";
            ps = conec.prepareStatement(sql);
            res = ps.executeQuery();
            while (res.next()) {
                String gerentes=res.getString("cantidad");
                System.out.println("cantidad: " + gerentes);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
    public ArrayList<empleados> buscarcargo(String clientes) {
        datos.clear();
        try {
            conec = con.conecta();
            String sql = " SELECT cc_Empleado,Nom_Empleado,Salario_Empleado FROM Empleados where Cargo=\"cajero\"\n";
            ps = conec.prepareStatement(sql);
            res = ps.executeQuery();
            while (res.next()) {
                empleados emp = new empleados(res.getString(1),res.getString(2),res.getString(3));
                datos.add(emp);
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return datos;
    }
}



