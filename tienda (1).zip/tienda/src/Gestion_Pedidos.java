import java.sql.*;
import java.util.ArrayList;

public class Gestion_Pedidos {
    public ArrayList<pedidos> Consultarpedidos;
    Conexion con = new Conexion();
    private ArrayList<pedidos> datos = new ArrayList();
    Statement st = null; //Preparar la consulta sin parametros
    PreparedStatement ps = null;//Prepara la consulta con parametros
    ResultSet res = null; //Almacenar el resultado de la consulta
    Connection conec = null;

    public ArrayList<pedidos> Consultarpedidos() {

        try {
            String sql = "select*from pedidos";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                pedidos pd = new pedidos(res.getInt(1), res.getString(2), res.getInt(3), res.getInt(4));
                datos.add(pd);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;
    }

    public pedidos buscarCod_Pedido(int Cod_Pedido) {
        pedidos pd = null;
        try {
            conec = con.conecta();
            String sql = "select * from pedidos where Cod_Pedido=?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, Cod_Pedido);
            res = ps.executeQuery();
            while (res.next()) {
                pd = new pedidos(res.getInt(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error al consultar: " + ex);
        }
        return pd;
    }

    public boolean insertarpedidos(pedidos pd) {
        boolean resultado = false;
        Gestion_Pedidos pedidos = new Gestion_Pedidos();
        Gestion_Distribuidores dt = new Gestion_Distribuidores();
        try {
            if (this.buscarCod_Pedido(pd.getCod_Pedido()) == null) {
                if (dt.buscarNit_Distribuidor(pd.getNit_Distribuidor()) != null) {
                    conec = con.conecta();
                    String sql = "insert into pedidos values (?,?,?,?)";
                    ps = conec.prepareStatement(sql);
                    ps.setInt(1, pd.getCod_Pedido());
                    ps.setString(2, pd.getNit_Distribuidor());
                    ps.setInt(3, pd.getCan_Total());
                    ps.setInt(4, pd.getCosto_Neto());
                    resultado = ps.executeUpdate() > 0;  //actualizar y agregar datos

                } else {
                    System.out.println("El Nit_Distribuidor no esta registrado ");
                }
            } else {
                System.out.println("El Pedido ya esta registrado");
            }
        } catch (SQLException ex) {
            System.out.println("Error al insertar: " + ex);
        }
        return resultado;
    }
    public  boolean actualizarpedidos(pedidos pds){
        boolean rt= false;

        try {
            conec=con.conecta();
            String sql="update pedidos set Nit_Distribuidor=?,Can_Total=?,Costo_Neto=? where Cod_Pedido=?";
            ps=conec.prepareStatement(sql);
            ps.setInt(1,pds.getCod_Pedido());
            ps.setString(2,pds.getNit_Distribuidor());
            ps.setInt(3,pds.getCan_Total());
            ps.setInt(4,pds.getCosto_Neto());
            rt=ps.executeUpdate()>0;


        }catch (SQLException w){
            System.out.println("error de consulta "+w);
        }
        return rt;
    }
    public boolean borrarPedidos(pedidos pd) {
        boolean resultado = false;
        try {
            conec = con.conecta();
            String sql = "DELETE FROM pedidos WHERE Cod_Pedido = ?";
            ps = conec.prepareStatement(sql);
            ps.setInt(1, pd.getCod_Pedido());
            int filasEliminadas = (ps.executeUpdate());
            if(filasEliminadas>=1){
                System.out.println("Fila Eliminada");
            }else{
                System.out.println("El sistema no lo reconoce como llave principal");
            }
        } catch (SQLException e) {
            System.out.println("SE HA PROVOCADO UN ERROR DE REGISTRO: NO SE BORRA PORQUE TIENE DATOS FORANEOS");
        }

        return resultado;
    }
    public ArrayList<pedidos> buscarcantidad(){

        try {
            String sql = "select Cod_pedido,Nit_Distribuidor, Can_total from pedidos where Costo_Neto<=100000";
            conec = con.conecta();//abrir conexion
            st = conec.createStatement();
            res = st.executeQuery(sql);

            while (res.next()) {
                pedidos pd = new pedidos(res.getInt(1), res.getString(2), res.getInt(3));
                datos.add(pd);
            }
        } catch (SQLException ex) {
            System.out.println("SE HA PROVOCADO UN ERROR DE CONSULTA: " + ex);
        }
        return datos;

    }
    public double promedioCostosPedidos() {
        double promedio = 0.0;
        int totalPedidos = 0;
        int totalCostos = 0;
        try {
            conec = con.conecta();
            String sql = "SELECT Costo_Neto FROM pedidos";
            ps = conec.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                totalCostos += rs.getInt("Costo_Neto");
                totalPedidos++;
            }
            if (totalPedidos > 0) {
                promedio = (double) totalCostos / (double) totalPedidos;
            }
            System.out.println("El promedio de los costos de los pedidos es: " + promedio);
        } catch (SQLException w) {
            System.out.println("error de consulta " + w);
        }
        return promedio;
    }
    public void listarPedidosMenoresA100() {
        try {
            conec = con.conecta();
            String sql = "SELECT Cod_Pedido, Nombre_Distribuidor, Can_Total FROM pedidos, distribuidores WHERE pedidos.Nit_Distribuidor = distribuidores.Nit_Distribuidor AND Can_Total < 100";
            ps = conec.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int codigoPedido = rs.getInt("Cod_Pedido");
                String nombreDistribuidor = rs.getString("Nombre_Distribuidor");
                int cantidadTotal = rs.getInt("Can_Total");
                System.out.println("Código del Pedido: " + codigoPedido + " | Distribuidor: " + nombreDistribuidor + " | Cantidad Total: " + cantidadTotal);
            }
        } catch (SQLException w) {
            System.out.println("error de consulta " + w);
        }
    }
    public void obtenerDistribuidorConMayorCostoNeto() {
        try {
            conec = con.conecta();
            String sql = "SELECT pedidos.Cod_Pedido, distribuidores.Nombre_Distribuidor "
                    + "FROM pedidos, distribuidores "
                    + "WHERE pedidos.Nit_Distribuidor = distribuidores.Nit_Distribuidor "
                    + "ORDER BY pedidos.Costo_Neto DESC "
                    + "LIMIT 1";
            ps = conec.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int codigoPedido = rs.getInt("Cod_Pedido");
                String nombreDistribuidor = rs.getString("Nombre_Distribuidor");
                System.out.println("Código del Pedido: " + codigoPedido + " | Distribuidor: " + nombreDistribuidor);
            }
        } catch (SQLException w) {
            System.out.println("error de consulta " + w);
        }
    }



}