public class distribuidores {
    public String Nombre_Distribuidor;
    public String Nit_Distribuidor;

    public distribuidores(String nombre_Distribuidor, String nit_Distribuidor) {
        Nombre_Distribuidor = nombre_Distribuidor;
        Nit_Distribuidor = nit_Distribuidor;
    }

    public distribuidores(String nombre_Distribuidor) {
        Nombre_Distribuidor = nombre_Distribuidor;
    }

    public String getNombre_Distribuidor() {
        return Nombre_Distribuidor;
    }

    public void setNombre_Distribuidor(String nombre_Distribuidor) {
        Nombre_Distribuidor = nombre_Distribuidor;
    }

    public String getNit_Distribuidor() {
        return Nit_Distribuidor;
    }

    public void setNit_Distribuidor(String nit_Distribuidor) {
        Nit_Distribuidor = nit_Distribuidor;
    }

    public distribuidores() {
    }

    @Override
    public String toString() {
        return "distribuidores{" +
                "\nNombre_Distribuidor: " + Nombre_Distribuidor + '\'' +
                "\nNit_Distribuidor: " + Nit_Distribuidor + '\'' +
                "\n\n";
    }
}
