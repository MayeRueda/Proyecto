public class pedidos_productos {
    public int Cod;
    public int Cod_Pedido;
    public int Cod_Producto;

    public pedidos_productos(int cod, int cod_Pedido, int cod_Producto) {
        Cod = cod;
        Cod_Pedido = cod_Pedido;
        Cod_Producto = cod_Producto;
    }

    public pedidos_productos(int cod) {
        Cod = cod;
    }

    public int getCod() {
        return Cod;
    }

    public void setCod(int cod) {
        Cod = cod;
    }

    public int getCod_Pedido() {
        return Cod_Pedido;
    }

    public void setCod_Pedido(int cod_Pedido) {
        Cod_Pedido = cod_Pedido;
    }

    public int getCod_Producto() {
        return Cod_Producto;
    }

    public void setCod_Producto(int cod_Producto) {
        Cod_Producto = cod_Producto;
    }

    public pedidos_productos() {
    }

    @Override
    public String toString() {
        return "pedidos_productos{" +
                "\nCod: " + Cod +
                "\nCod_Pedido: " + Cod_Pedido +
                "\nCod_Producto: " + Cod_Producto +
                "\n\n";
    }
}
