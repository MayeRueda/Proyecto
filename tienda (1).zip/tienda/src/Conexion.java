import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private String bd="tienda_x";
    private String url="jdbc:mysql://localhost:3306/"+bd;
    private String user="root";
    private String pass="1234";

    Connection conec=null;

    public Connection conecta(){

        try{
            conec= DriverManager.getConnection(url,user,pass);
            System.out.println("conexion OK");

        }catch(SQLException e){
            System.out.println("error en la conexion"+e);
        }
        return conec;

    }
}

